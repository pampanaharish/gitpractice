var a=1;
let b=2;
const c=3;

a=5;
// let b;
b=6;
// c=7;
var a=10
console.log(a)
console.log(b)
console.log(c)


document.getElementById('demo1').innerHTML="Hello World"
document.getElementById('demo').style.backgroundColor=red;